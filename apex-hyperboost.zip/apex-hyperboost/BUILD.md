# Build, run, sign

Requirements: Android Studio Koala (2024.1.1)+ or JDK 17 + Gradle 8.7+, Android SDK 35. Device: Android 12 (API 31)+.

1. Android Studio: File > Open > select this folder. Let Gradle sync (it generates the wrapper).
   CLI alternative: `gradle wrapper --gradle-version 8.7`
2. Debug run: connect a device with USB debugging, press Run. Or `./gradlew installDebug`.
3. Create a keystore (once):
   `keytool -genkeypair -v -keystore apex-release.jks -alias apex -keyalg RSA -keysize 2048 -validity 10000`
4. Signed release APK:
   ```
   export APEX_KEYSTORE=/absolute/path/apex-release.jks
   export APEX_STORE_PASS=...  APEX_KEY_ALIAS=apex  APEX_KEY_PASS=...
   ./gradlew assembleRelease
   ```
   Output: app/build/outputs/apk/release/app-release.apk (already v2/v3 signed by AGP).
5. Verify: `apksigner verify --verbose app/build/outputs/apk/release/app-release.apk`
6. Android Studio GUI route: Build > Generate Signed App Bundle / APK > APK.
