package com.apex.hyperboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Foreground service: samples the real FPS of whatever app is in front and shows it in an overlay. */
class BoostService : Service() {

    companion object {
        const val ACTION_STOP = "com.apex.hyperboost.STOP"
        private const val CHANNEL = "session"
        private const val NOTIF_ID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var nm: NotificationManager
    private lateinit var wm: WindowManager
    private var overlay: TextView? = null
    private var started = false

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        wm = getSystemService(WindowManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Game session", NotificationManager.IMPORTANCE_LOW))
        ShizukuBridge.init(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, build("Session active"), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (!started) {
            started = true
            showOverlay()
            scope.launch {
                PerformanceEngine.get(this@BoostService).thermal.collect { nm.notify(NOTIF_ID, build("Thermal: $it")) }
            }
            scope.launch { sampleLoop() }
        }
        return START_STICKY
    }

    private suspend fun sampleLoop() {
        var pkg: String? = null
        var tick = 0
        while (scope.isActive) {
            if (ShizukuBridge.state.value != ShizukuBridge.State.READY) {
                ShizukuBridge.refresh()
                setOverlayText("Shizuku chưa chạy")
                delay(2000)
                continue
            }
            if (tick % 3 == 0) pkg = GameTuner.foregroundPackage() ?: pkg
            val p = pkg
            val s = if (p != null && p != packageName) GameTuner.sampleFps(p) else null
            FpsHub.pkg.value = p.orEmpty()
            FpsHub.sample.value = s
            val name = p?.substringAfterLast('.') ?: "--"
            setOverlayText(
                when {
                    s == null -> "$name\nFPS --"
                    else -> "$name\nFPS ${s.fps} · ${s.stability}%"
                }
            )
            tick++
            delay(1000)
        }
    }

    private suspend fun setOverlayText(t: String) {
        withContext(Dispatchers.Main) { overlay?.text = t }
    }

    private fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val tv = TextView(this).apply {
            setTextColor(0xFF00F0FF.toInt())
            setBackgroundColor(0x99000000.toInt())
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(18, 8, 18, 8)
            text = "FPS --"
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 90
        }
        runCatching { wm.addView(tv, lp) }.onSuccess { overlay = tv }
    }

    override fun onDestroy() {
        scope.cancel()
        overlay?.let { v -> runCatching { wm.removeView(v) } }
        overlay = null
        FpsHub.sample.value = null
        FpsHub.pkg.value = ""
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun build(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, BoostService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("APEX HYPER-BOOST")
            .setContentText(text)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()
    }
}
