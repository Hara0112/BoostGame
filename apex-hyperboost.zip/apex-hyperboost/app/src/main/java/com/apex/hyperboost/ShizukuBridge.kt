package com.apex.hyperboost

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object ShizukuBridge {

    enum class State { NOT_RUNNING, NEED_PERMISSION, READY }

    private val _state = MutableStateFlow(State.NOT_RUNNING)
    val state: StateFlow<State> = _state.asStateFlow()

    @Volatile private var svc: IUserService? = null
    @Volatile private var bound = false
    private var inited = false
    private lateinit var app: Context

    private val onReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener {
        svc = null
        bound = false
        _state.value = State.NOT_RUNNING
    }
    private val onPermission = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) svc = IUserService.Stub.asInterface(binder)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            bound = false
        }
    }

    fun init(ctx: Context) {
        if (!inited) {
            inited = true
            app = ctx.applicationContext
            Shizuku.addBinderReceivedListenerSticky(onReceived)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPermission)
        }
        refresh()
    }

    fun refresh() {
        if (!inited) return
        if (!Shizuku.pingBinder()) {
            _state.value = State.NOT_RUNNING
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            _state.value = State.READY
            bind()
        } else {
            _state.value = State.NEED_PERMISSION
        }
    }

    fun requestPermission() {
        if (inited && Shizuku.pingBinder()) Shizuku.requestPermission(1001)
    }

    private fun bind() {
        if (bound) return
        bound = true
        val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, ShellService::class.java.name))
            .processNameSuffix("shell")
            .daemon(false)
            .version(1)
        Shizuku.bindUserService(args, conn)
    }

    /** Runs a shell command as uid 2000 (adb shell). Returns combined stdout/stderr. */
    suspend fun sh(cmd: String): String = withContext(Dispatchers.IO) {
        var tries = 0
        while (svc == null && tries < 50) {
            delay(100)
            tries++
        }
        val s = svc ?: return@withContext "ERR: Shizuku not connected"
        try {
            s.exec(cmd)
        } catch (e: Exception) {
            "ERR: ${e.message}"
        }
    }
}
