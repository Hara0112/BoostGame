package com.apex.hyperboost

/** Runs inside the Shizuku-started process with shell (adb, uid 2000) privileges. */
class ShellService : IUserService.Stub() {

    override fun destroy() {
        System.exit(0)
    }

    override fun exec(command: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (e: Exception) {
            "ERR: ${e.message}"
        }
    }
}
