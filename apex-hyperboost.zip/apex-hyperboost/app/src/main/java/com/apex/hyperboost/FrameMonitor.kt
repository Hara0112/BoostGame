package com.apex.hyperboost

import android.app.Activity
import android.os.Handler
import android.os.HandlerThread
import android.view.Choreographer
import android.view.FrameMetrics
import android.view.Window
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class FrameStats(
    val fps: Int = 0,
    val stability: Int = 100,   // % of last 120 frames that met the vsync budget
    val dropped: Int = 0,       // vsyncs missed in the last 1 s window
    val worstMs: Float = 0f,
    val refreshHz: Float = 60f
)

/** Construct and call start()/stop() on the main thread. */
class FrameMonitor(private val onFrameWork: (Long) -> Unit = {}) : Choreographer.FrameCallback {

    private val _stats = MutableStateFlow(FrameStats())
    val stats: StateFlow<FrameStats> = _stats.asStateFlow()

    private val choreographer = Choreographer.getInstance()
    private var running = false
    private var refreshHz = 60f
    private var budgetNs = 16_666_667L

    private var lastNs = 0L
    private var winStartNs = 0L
    private var winFrames = 0
    private var winDropped = 0
    private var winWorstNs = 0L

    private val ring = BooleanArray(120) // true = janky frame
    private var ringIdx = 0
    private var ringFill = 0

    private var metricsThread: HandlerThread? = null
    private var metricsListener: Window.OnFrameMetricsAvailableListener? = null

    fun start(hz: Float) {
        if (running) return
        refreshHz = hz.coerceIn(30f, 240f)
        budgetNs = (1_000_000_000L / refreshHz).toLong()
        lastNs = 0L; winStartNs = 0L; winFrames = 0; winDropped = 0; winWorstNs = 0L
        running = true
        choreographer.postFrameCallback(this)
    }

    fun stop() {
        running = false
        choreographer.removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (winStartNs == 0L) winStartNs = frameTimeNanos

        if (lastNs != 0L) {
            val dt = frameTimeNanos - lastNs
            val missed = ((dt + budgetNs / 2) / budgetNs - 1).coerceAtLeast(0L).toInt()
            winFrames++
            winDropped += missed
            if (dt > winWorstNs) winWorstNs = dt
            ring[ringIdx] = missed > 0
            ringIdx = (ringIdx + 1) % ring.size
            if (ringFill < ring.size) ringFill++
        }
        lastNs = frameTimeNanos

        val elapsed = frameTimeNanos - winStartNs
        if (elapsed >= 1_000_000_000L) {
            var jank = 0
            for (i in 0 until ringFill) if (ring[i]) jank++
            val stability = if (ringFill == 0) 100 else 100 - jank * 100 / ringFill
            _stats.value = FrameStats(
                fps = (winFrames * 1e9 / elapsed).toInt(),
                stability = stability,
                dropped = winDropped,
                worstMs = winWorstNs / 1e6f,
                refreshHz = refreshHz
            )
            winStartNs = frameTimeNanos; winFrames = 0; winDropped = 0; winWorstNs = 0L
        }
        choreographer.postFrameCallback(this)
    }

    /** Per-frame total render duration from the framework, forwarded to the ADPF hint session. */
    fun attach(activity: Activity) {
        if (metricsListener != null) return
        val thread = HandlerThread("apex-frame-metrics").also { it.start() }
        val l = Window.OnFrameMetricsAvailableListener { _, fm, _ ->
            onFrameWork(fm.getMetric(FrameMetrics.TOTAL_DURATION))
        }
        activity.window.addOnFrameMetricsAvailableListener(l, Handler(thread.looper))
        metricsThread = thread
        metricsListener = l
    }

    fun detach(activity: Activity) {
        metricsListener?.let { activity.window.removeOnFrameMetricsAvailableListener(it) }
        metricsListener = null
        metricsThread?.quitSafely()
        metricsThread = null
    }
}
