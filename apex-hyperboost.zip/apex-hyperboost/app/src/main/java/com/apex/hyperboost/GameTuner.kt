package com.apex.hyperboost

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

data class FpsSample(val fps: Int, val stability: Int, val jank: Int)

/** Shared live state so the UI and the overlay service see the same numbers. */
object FpsHub {
    val pkg = MutableStateFlow("")
    val sample = MutableStateFlow<FpsSample?>(null)
}

/** All actions go through Shizuku (shell privilege). Nothing here needs root. */
object GameTuner {

    data class AppInfo(val pkg: String, val label: String, val isGame: Boolean)

    private val PROTECT_WORDS = listOf(
        "dialer", "contacts", "incallui", "messaging", "mms", "systemui",
        "inputmethod", "keyboard", "launcher", "telecom"
    )

    private var layerCache: Pair<String, String>? = null
    private var prevLast = 0L
    private var prevTotal = 0L
    private var prevIdle = 0L

    fun launchableApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != ctx.packageName }
            .map { AppInfo(it.packageName, it.loadLabel(pm).toString(), it.category == ApplicationInfo.CATEGORY_GAME) }
            .sortedWith(compareByDescending<AppInfo> { it.isGame }.thenBy { it.label.lowercase() })
    }

    // ------------------------------------------------------------- actions

    /** Performance-oriented system settings. Each command is best-effort; unsupported ones just print an error. */
    suspend fun boostSystem(refreshHz: Float): String {
        val hz = String.format(Locale.US, "%.1f", refreshHz)
        return ShizukuBridge.sh(
            "cmd power set-fixed-performance-mode-enabled true; " +
                "settings put global low_power 0; " +
                "settings put system min_refresh_rate $hz; " +
                "settings put system peak_refresh_rate $hz"
        )
    }

    suspend fun setGameMode(pkg: String): String = ShizukuBridge.sh("cmd game mode performance $pkg").trim()

    suspend fun compile(pkg: String): String = ShizukuBridge.sh("cmd package compile -m speed-profile -f $pkg").trim()

    private suspend fun protectedPackages(ctx: Context, keep: String): Set<String> {
        val home = ctx.packageManager
            .resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        val ime = ShizukuBridge.sh("settings get secure default_input_method").trim().substringBefore('/')
        return setOfNotNull(keep, ctx.packageName, "moe.shizuku.privileged.api", home, ime)
    }

    /** Force-stops launchable apps that currently have a running process. Returns how many were stopped. */
    suspend fun killBackground(ctx: Context, keep: String): Int {
        val launchable = launchableApps(ctx).map { it.pkg }.toSet()
        val running = ShizukuBridge.sh("ps -A -o NAME").lineSequence()
            .map { it.trim().substringBefore(':') }
            .filter { it in launchable }
            .toSet()
        val protectedSet = protectedPackages(ctx, keep)
        val victims = running.filter { p -> p !in protectedSet && PROTECT_WORDS.none { p.contains(it) } }
        if (victims.isNotEmpty()) {
            ShizukuBridge.sh(victims.joinToString("; ") { "am force-stop $it" })
        }
        return victims.size
    }

    suspend fun undo(pkg: String?): String {
        val parts = mutableListOf(
            "cmd power set-fixed-performance-mode-enabled false",
            "settings delete system min_refresh_rate",
            "settings delete system peak_refresh_rate"
        )
        if (pkg != null) parts += "cmd game mode standard $pkg"
        return ShizukuBridge.sh(parts.joinToString("; "))
    }

    // ------------------------------------------------------------ monitoring

    suspend fun foregroundPackage(): String? {
        val out = ShizukuBridge.sh(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2"
        )
        return Regex("""u\d+\s+([\w.]+)/""").find(out)?.groupValues?.get(1)
    }

    /** System-wide CPU load from /proc/stat (readable with shell privilege only). -1 on failure. */
    suspend fun cpuPercent(): Int {
        val line = ShizukuBridge.sh("head -n 1 /proc/stat")
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return -1
        val idle = p[3] + p.getOrElse(4) { 0L }
        val total = p.sum()
        val first = prevTotal == 0L
        val dTotal = total - prevTotal
        val dIdle = idle - prevIdle
        prevTotal = total
        prevIdle = idle
        if (first || dTotal <= 0) return 0
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    private suspend fun readFrames(layer: String): List<Long> {
        val out = ShizukuBridge.sh("dumpsys SurfaceFlinger --latency '$layer'")
        return out.lineSequence().drop(1).mapNotNull { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 3) null
            else parts[1].toLongOrNull()?.takeIf { it > 0 && it != Long.MAX_VALUE }
        }.toList()
    }

    /** Real presented-frame timestamps of the game's SurfaceFlinger layer. */
    suspend fun sampleFps(pkg: String): FpsSample? {
        val cached = layerCache?.takeIf { it.first == pkg }?.second
        var frames: List<Long> = if (cached != null) readFrames(cached) else emptyList()
        if (frames.size < 3) {
            val layers = ShizukuBridge.sh("dumpsys SurfaceFlinger --list").lineSequence()
                .map { it.trim() }.filter { it.contains(pkg) }.toList()
            var bestLayer: String? = null
            var bestFrames: List<Long> = emptyList()
            for (l in layers) {
                val f = readFrames(l)
                if (f.size > bestFrames.size) {
                    bestFrames = f
                    bestLayer = l
                }
            }
            if (bestLayer == null || bestFrames.size < 3) return null
            layerCache = pkg to bestLayer
            frames = bestFrames
        }
        val ts = frames.sorted()
        val last = ts.last()
        if (last == prevLast) return FpsSample(0, 100, 0) // no new frames since the last sample
        prevLast = last
        val win = ts.filter { it >= last - 1_000_000_000L }
        if (win.size < 2) return FpsSample(win.size, 100, 0)
        val span = win.last() - win.first()
        val fps = if (span > 0) ((win.size - 1) * 1e9 / span).toInt() else 0
        val gaps = win.zipWithNext { a, b -> b - a }
        val median = gaps.sorted()[gaps.size / 2]
        val jank = gaps.count { it > median * 3 / 2 }
        val stability = (100 - jank * 100 / gaps.size).coerceIn(0, 100)
        return FpsSample(fps, stability, jank)
    }
}
