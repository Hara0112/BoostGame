package com.apex.hyperboost

import android.app.Activity
import android.app.ActivityManager
import android.app.GameManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.PerformanceHintManager
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

data class MemStats(val usedPercent: Int, val availMb: Long, val totalMb: Long)
data class BoostResult(val signalled: Int, val deltaAvailMb: Long, val threadsElevated: Int)

/**
 * Everything here uses public, non-root APIs. Capabilities that need root/system
 * privileges (CPU governor writes, system-wide DNS flush, other apps' thread priority)
 * are intentionally absent: the OS rejects them for third-party apps.
 */
class PerformanceEngine private constructor(context: Context) {

    companion object {
        @Volatile private var instance: PerformanceEngine? = null
        fun get(c: Context): PerformanceEngine =
            instance ?: synchronized(this) {
                instance ?: PerformanceEngine(c.applicationContext).also { instance = it }
            }

        private val THERMAL = arrayOf("NONE", "LIGHT", "MODERATE", "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN")
    }

    private val ctx: Context = context
    private val am: ActivityManager = ctx.getSystemService(ActivityManager::class.java)
    private val pm: PowerManager = ctx.getSystemService(PowerManager::class.java)
    private val cm: ConnectivityManager = ctx.getSystemService(ConnectivityManager::class.java)

    private val _thermal = MutableStateFlow(thermalLabel(pm.currentThermalStatus))
    val thermal: StateFlow<String> = _thermal.asStateFlow()

    @Volatile private var hint: PerformanceHintManager.Session? = null
    private var lastCpuMs = Process.getElapsedCpuTime()
    private var lastWallMs = SystemClock.elapsedRealtime()

    init {
        pm.addThermalStatusListener(ctx.mainExecutor) { _thermal.value = thermalLabel(it) }
    }

    private fun thermalLabel(s: Int) = THERMAL.getOrElse(s) { "UNKNOWN" }

    // ---------------------------------------------------------------- telemetry

    fun memory(): MemStats {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val used = if (mi.totalMem > 0) ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt() else 0
        return MemStats(used.coerceIn(0, 100), mi.availMem shr 20, mi.totalMem shr 20)
    }

    /** CPU load of THIS process, normalised across cores. /proc/stat is blocked for apps since Android 8. */
    @Synchronized
    fun appCpuPercent(): Int {
        val cpu = Process.getElapsedCpuTime()
        val wall = SystemClock.elapsedRealtime()
        val dCpu = cpu - lastCpuMs
        val dWall = wall - lastWallMs
        lastCpuMs = cpu
        lastWallMs = wall
        if (dWall <= 0) return 0
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        return (dCpu * 100 / (dWall * cores)).toInt().coerceIn(0, 100)
    }

    fun batteryTempC(): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    /** Forecast 10 s ahead. ~1.0 means severe throttling is expected; NaN if unsupported by the device. */
    fun thermalHeadroom(): Float = pm.getThermalHeadroom(10)

    fun gameModeLabel(): String {
        val gm = ctx.getSystemService(GameManager::class.java) ?: return "UNSUPPORTED"
        return when (gm.gameMode) {
            GameManager.GAME_MODE_PERFORMANCE -> "PERFORMANCE"
            GameManager.GAME_MODE_BATTERY -> "BATTERY"
            GameManager.GAME_MODE_STANDARD -> "STANDARD"
            GameManager.GAME_MODE_CUSTOM -> "CUSTOM"
            else -> "UNSUPPORTED"
        }
    }

    // ------------------------------------------------- threads / ADPF / display

    private fun uiTids(): IntArray {
        val main = Process.myPid()
        return File("/proc/self/task").list().orEmpty().mapNotNull { id ->
            val tid = id.toIntOrNull() ?: return@mapNotNull null
            val name = runCatching { File("/proc/self/task/$id/comm").readText().trim() }.getOrDefault("")
            if (tid == main || name == "RenderThread") tid else null
        }.toIntArray()
    }

    /** Raises only the main thread and RenderThread; raising every thread starves the render pipeline. */
    fun elevateUiThreads(): Int {
        var ok = 0
        for (tid in uiTids()) {
            if (runCatching { Process.setThreadPriority(tid, Process.THREAD_PRIORITY_URGENT_DISPLAY) }.isSuccess) ok++
        }
        return ok
    }

    /** Idempotent. Needs RenderThread to exist, so it is retried from the telemetry loop until it succeeds. */
    @Synchronized
    fun ensureUiBoost(refreshHz: Float) {
        if (hint != null) return
        val tids = uiTids()
        if (tids.size < 2) return
        elevateUiThreads()
        val mgr = ctx.getSystemService(PerformanceHintManager::class.java) ?: return
        val target = (1_000_000_000L / refreshHz.coerceIn(30f, 240f)).toLong()
        hint = runCatching { mgr.createHintSession(tids, target) }.getOrNull()
    }

    /** Feeds real per-frame work time to the CPU governor via ADPF. This is the sanctioned anti-downclock path. */
    fun reportFrameWork(ns: Long) {
        if (ns > 0) runCatching { hint?.reportActualWorkDuration(ns) }
    }

    fun applyWindowProfile(activity: Activity) {
        if (pm.isSustainedPerformanceModeSupported) activity.window.setSustainedPerformanceMode(true)
        val display = activity.display ?: return
        val cur = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .maxByOrNull { it.refreshRate } ?: return
        val lp = activity.window.attributes
        lp.preferredDisplayModeId = best.modeId
        activity.window.attributes = lp
    }

    // -------------------------------------------------------------- RAM sweep

    private fun launchablePackages(): Set<String> {
        val pmgr = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val home = pmgr.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        return pmgr.queryIntentActivities(launcher, PackageManager.ResolveInfoFlags.of(0))
            .map { it.activityInfo.packageName }
            .filter { it != ctx.packageName && it != home }
            .toSet()
    }

    /**
     * killBackgroundProcesses() only terminates processes the OS already classifies as safely
     * killable (cached / background). Foreground, service-bound and system processes are untouched.
     */
    suspend fun boost(): BoostResult = withContext(Dispatchers.Default) {
        val elevated = elevateUiThreads()
        val before = memory().availMb
        val pkgs = launchablePackages()
        pkgs.forEach { runCatching { am.killBackgroundProcesses(it) } }
        delay(700)
        val after = memory().availMb
        BoostResult(pkgs.size, after - before, elevated)
    }

    // ------------------------------------------------------------ network

    private fun tune(s: Socket) {
        s.tcpNoDelay = true
        s.keepAlive = true
        s.sendBufferSize = 256 * 1024
        s.receiveBufferSize = 256 * 1024
        s.trafficClass = 0x10 // IPTOS_LOWDELAY
        s.soTimeout = 1500
    }

    /** Tuned-socket factory for your own game/network code. */
    fun newTunedSocket(): Socket {
        val s = cm.activeNetwork?.socketFactory?.createSocket() ?: Socket()
        tune(s)
        return s
    }

    /** TCP connect RTT in ms to a public anycast endpoint; -1 on failure. */
    suspend fun probeLatency(host: String = "1.1.1.1", port: Int = 443): Long =
        withContext(Dispatchers.IO) {
            val s = runCatching { newTunedSocket() }.getOrNull() ?: return@withContext -1L
            try {
                val t0 = SystemClock.elapsedRealtimeNanos()
                s.connect(InetSocketAddress(host, port), 1500)
                (SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000L
            } catch (e: Exception) {
                -1L
            } finally {
                runCatching { s.close() }
            }
        }
}
