package com.apex.hyperboost

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Obsidian = Color(0xFF0B0E14)
private val NeonCyan = Color(0xFF00F0FF)
private val LaserCrimson = Color(0xFFFF0055)

data class Telemetry(val cpu: Int = 0, val ram: Int = 0, val tempC: Float = 0f, val headroom: Float = Float.NaN)

class MainActivity : ComponentActivity() {

    private lateinit var engine: PerformanceEngine
    private val monitor by lazy { FrameMonitor { ns -> engine.reportFrameWork(ns) } }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        engine = PerformanceEngine.get(this)
        ShizukuBridge.init(applicationContext)
        engine.applyWindowProfile(this)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { HudApp(engine, monitor) }
    }

    override fun onResume() {
        super.onResume()
        ShizukuBridge.refresh()
        monitor.start(display?.refreshRate ?: 60f)
        monitor.attach(this)
    }

    override fun onPause() {
        monitor.stop()
        monitor.detach(this)
        super.onPause()
    }
}

@Composable
fun HudApp(engine: PerformanceEngine, monitor: FrameMonitor) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    val frame by monitor.stats.collectAsState()
    val thermal by engine.thermal.collectAsState()
    val shizuku by ShizukuBridge.state.collectAsState()
    val live by FpsHub.sample.collectAsState()
    val livePkg by FpsHub.pkg.collectAsState()
    var tele by remember { mutableStateOf(Telemetry()) }
    val ramHistory = remember { mutableStateListOf<Int>() }
    var rtt by remember { mutableLongStateOf(-1L) }
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("Sẵn sàng.") }
    var apps by remember { mutableStateOf(emptyList<GameTuner.AppInfo>()) }
    var target by remember { mutableStateOf<GameTuner.AppInfo?>(null) }
    var pickerOpen by remember { mutableStateOf(false) }
    var optPerf by remember { mutableStateOf(true) }
    var optMode by remember { mutableStateOf(true) }
    var optKill by remember { mutableStateOf(true) }
    var optCompile by remember { mutableStateOf(true) }
    val gameMode = remember { engine.gameModeLabel() }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { GameTuner.launchableApps(ctx) }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            val t = withContext(Dispatchers.Default) {
                engine.ensureUiBoost(monitor.stats.value.refreshHz)
                val m = engine.memory()
                val sysCpu = if (ShizukuBridge.state.value == ShizukuBridge.State.READY)
                    GameTuner.cpuPercent().takeIf { it >= 0 } else null
                Telemetry(sysCpu ?: engine.appCpuPercent(), m.usedPercent, engine.batteryTempC(), engine.thermalHeadroom())
            }
            tele = t
            ramHistory.add(t.ram)
            if (ramHistory.size > 60) ramHistory.removeAt(0)
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            rtt = engine.probeLatency()
            delay(5000)
        }
    }

    val gameFps = live?.fps ?: 0
    val gameStab = live?.stability ?: 0
    val fpsColor = if (live != null && gameStab < 90) LaserCrimson else NeonCyan
    val tempColor = if (tele.tempC >= 42f) LaserCrimson else NeonCyan
    val cpuColor = if (tele.cpu >= 85) LaserCrimson else NeonCyan

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Obsidian, Color(0xFF05070B))))
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("APEX HYPER-BOOST", color = NeonCyan, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("SHIZUKU EDITION", color = Color.White.copy(0.5f), fontSize = 11.sp, letterSpacing = 3.sp)

        GlassCard(Modifier.fillMaxWidth()) {
            val (txt, col) = when (shizuku) {
                ShizukuBridge.State.READY -> "SHIZUKU: SẴN SÀNG" to NeonCyan
                ShizukuBridge.State.NEED_PERMISSION -> "SHIZUKU: CẦN CẤP QUYỀN" to LaserCrimson
                ShizukuBridge.State.NOT_RUNNING -> "SHIZUKU: CHƯA CHẠY" to LaserCrimson
            }
            Text(txt, color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            if (shizuku != ShizukuBridge.State.READY) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionChip("Mở Shizuku") {
                        ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
                    }
                    if (shizuku == ShizukuBridge.State.NEED_PERMISSION) {
                        ActionChip("Cấp quyền") { ShizukuBridge.requestPermission() }
                    }
                    ActionChip("Kiểm tra lại") { ShizukuBridge.refresh() }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RadialGauge(tele.cpu.toFloat(), 100f, "${tele.cpu}%", "CPU", cpuColor)
                RadialGauge(tele.tempC, 60f, "%.1f°".format(tele.tempC), "BATTERY °C", tempColor)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RadialGauge(gameFps.toFloat(), frame.refreshHz, "$gameFps", "GAME FPS · $gameStab%", fpsColor)
                RadialGauge(tele.ram.toFloat(), 100f, "${tele.ram}%", "RAM USED", NeonCyan)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("RAM TIMELINE · 60 s", color = Color.White.copy(0.6f), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            RamGraph(ramHistory, Modifier.fillMaxWidth().height(90.dp))
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Stat("ĐANG ĐO", if (livePkg.isEmpty()) "—" else livePkg.substringAfterLast('.'), NeonCyan)
            Stat("TỤT KHUNG (1 s)", "${live?.jank ?: 0}", if ((live?.jank ?: 0) > 0) LaserCrimson else NeonCyan)
            Stat("THERMAL", thermal, if (thermal == "NONE" || thermal == "LIGHT") NeonCyan else LaserCrimson)
            Stat(
                "THERMAL HEADROOM",
                if (tele.headroom.isNaN()) "N/A" else "%.2f".format(tele.headroom),
                if (!tele.headroom.isNaN() && tele.headroom > 0.85f) LaserCrimson else NeonCyan
            )
            Stat("NET RTT", if (rtt < 0) "OFFLINE" else "$rtt ms", if (rtt < 0 || rtt > 100) LaserCrimson else NeonCyan)
            Stat("GAME MODE (APP NÀY)", gameMode, NeonCyan)
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("GAME MỤC TIÊU", color = Color.White.copy(0.6f), fontSize = 11.sp, letterSpacing = 2.sp)
            Text(
                target?.label ?: "Chưa chọn — chạm để chọn",
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().clickable { pickerOpen = !pickerOpen }.padding(vertical = 10.dp)
            )
            if (pickerOpen) {
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    apps.forEach { a ->
                        Text(
                            (if (a.isGame) "🎮 " else "") + a.label,
                            color = if (a.pkg == target?.pkg) NeonCyan else Color.White.copy(0.8f),
                            modifier = Modifier.fillMaxWidth().clickable { target = a; pickerOpen = false }.padding(vertical = 9.dp)
                        )
                    }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            ToggleRow("Hiệu năng hệ thống cao", optPerf) { optPerf = it }
            ToggleRow("Game Mode: Performance", optMode) { optMode = it }
            ToggleRow("Đóng ứng dụng nền", optKill) { optKill = it }
            ToggleRow("Biên dịch lại game", optCompile) { optCompile = it }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BoostButton(busy) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                busy = true
                scope.launch {
                    ShizukuBridge.refresh()
                    if (ShizukuBridge.state.value != ShizukuBridge.State.READY) {
                        report = "Cần bật Shizuku và cấp quyền trước (xem thẻ SHIZUKU ở trên)."
                        busy = false
                        return@launch
                    }
                    val steps = mutableListOf<String>()
                    val t = target
                    ShizukuBridge.sh("appops set ${ctx.packageName} SYSTEM_ALERT_WINDOW allow")
                    ctx.startForegroundService(Intent(ctx, BoostService::class.java))
                    if (optPerf) {
                        report = "Đang bật hiệu năng cao…"
                        GameTuner.boostSystem(frame.refreshHz)
                        steps += "hiệu năng hệ thống"
                    }
                    if (optKill) {
                        report = "Đang đóng ứng dụng nền…"
                        val n = GameTuner.killBackground(ctx, t?.pkg.orEmpty())
                        steps += "đã đóng $n ứng dụng nền"
                    }
                    if (t != null && optMode) {
                        GameTuner.setGameMode(t.pkg)
                        steps += "Game Mode Performance"
                    }
                    if (t != null && optCompile) {
                        report = "Đang biên dịch ${t.label} (có thể mất 1–2 phút)…"
                        GameTuner.compile(t.pkg)
                        steps += "đã biên dịch game"
                    }
                    if (t != null) {
                        ctx.packageManager.getLaunchIntentForPackage(t.pkg)?.let {
                            ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    report = "Hoàn tất: " + steps.joinToString(", ") + ". Số FPS hiện trên màn hình khi chơi."
                    busy = false
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            }
        }
        Text(report, color = Color.White.copy(0.7f), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            ActionChip("Hoàn tác & tắt FPS") {
                scope.launch {
                    GameTuner.undo(target?.pkg)
                    ctx.stopService(Intent(ctx, BoostService::class.java))
                    report = "Đã hoàn tác cài đặt và tắt lớp phủ FPS."
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ActionChip(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Text(
        text, color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, NeonCyan.copy(0.6f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White.copy(0.85f), fontSize = 14.sp)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = NeonCyan,
                uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.White.copy(0.1f)
            )
        )
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(0.10f), Color.White.copy(0.03f))))
            .border(1.dp, Brush.linearGradient(listOf(NeonCyan.copy(0.7f), LaserCrimson.copy(0.45f))), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Stat(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White.copy(0.55f), fontSize = 11.sp, letterSpacing = 2.sp)
        Text(value, color = color, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RadialGauge(value: Float, max: Float, center: String, label: String, color: Color, modifier: Modifier = Modifier) {
    val frac by animateFloatAsState((value / max).coerceIn(0f, 1f), spring(stiffness = Spring.StiffnessLow), label = "gauge")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 10.dp.toPx()
                val tl = Offset(sw, sw)
                val sz = Size(size.width - 2 * sw, size.height - 2 * sw)
                drawArc(Color.White.copy(0.08f), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(color.copy(0.25f), 135f, 270f * frac, false, tl, sz, style = Stroke(sw * 1.8f, cap = StrokeCap.Round))
                drawArc(color, 135f, 270f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text(center, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Text(label, color = color, fontSize = 10.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun RamGraph(samples: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (samples.size < 2) return@Canvas
        val dx = size.width / 59f
        val line = Path()
        val fill = Path()
        samples.forEachIndexed { i, v ->
            val x = i * dx
            val y = size.height * (1f - v / 100f)
            if (i == 0) {
                line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y)
            } else {
                line.lineTo(x, y); fill.lineTo(x, y)
            }
        }
        fill.lineTo((samples.size - 1) * dx, size.height)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(NeonCyan.copy(0.35f), Color.Transparent)))
        drawPath(line, NeonCyan, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun BoostButton(busy: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.88f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )
    val ring by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (busy) 900 else 4000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "ring"
    )
    val accent = if (busy) LaserCrimson else NeonCyan

    Box(
        Modifier
            .size(210.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(accent.copy(0.40f), Color.Transparent)), radius = r * pulse)
            drawCircle(accent.copy(0.15f), radius = r * 0.62f)
            drawCircle(accent, radius = r * 0.62f, style = Stroke(3.dp.toPx()))
            drawArc(
                accent, ring, 70f, false,
                Offset(size.width / 2 - r * 0.78f, size.height / 2 - r * 0.78f),
                Size(r * 1.56f, r * 1.56f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        Text(
            if (busy) "BOOSTING…" else "HYPER\nBOOST",
            color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp,
            letterSpacing = 3.sp, textAlign = TextAlign.Center
        )
    }
}
